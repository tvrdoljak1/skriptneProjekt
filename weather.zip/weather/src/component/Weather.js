import React from 'react';
import moment from 'moment';

class Weather extends React.Component{

 state = {term: undefined}
    constructor(props) {
        super(props);
        this.showMore = false;
    }

    toggleClick = () => {
       this.showMore = !this.showMore;
       this.setState({term: 2})
    }
    
    render() {

        return (
            <div className="align-items-start main">

                {this.props.city && this.props.country && <div className="weather__info">Location: {this.props.city}, {this.props.country}</div> }
                {this.props.temperature && this.props.description && this.props.humidity && <div className="weather__info">Temperature: {this.props.temperature}, Conditions: {this.props.description}, Humidity: {this.props.humidity}</div>}
                {this.props.hour1 && (
                    <div className="col-sm weather__key">
                        Hour: <span className="col-sm weather__value">{moment(this.props.hour1[0]).format('lll')}</span>
                        Temperature: <span className="col-sm weather__value">{this.props.hour1[1]}</span>
                        Description: <span className="col-sm weather__value">{this.props.hour1[2]}</span>
                        Humidity: <span className="col-sm weather__value">{this.props.hour1[3]}</span>
                    </div>
                )}
                {this.props.hour2 && (
                    <div className="col-sm weather__key">
                        Hour: <span className="col-sm weather__value">{moment(this.props.hour2[0]).format('lll')}</span>
                        Temperature: <span className="col-sm weather__value">{this.props.hour2[1]}</span>
                        Description: <span className="col-sm weather__value">{this.props.hour2[2]}</span>
                        Humidity: <span className="col-sm weather__value">{this.props.hour2[3]}</span>
                    </div>
                )}
                {this.props.hour3 && (
                    <div className="col-sm weather__key">
                        Hour: <span className="col-sm weather__value">{moment(this.props.hour3[0]).format('lll')}</span>
                        Temperature: <span className="col-sm weather__value">{this.props.hour3[1]}</span>
                        Description: <span className="col-sm weather__value">{this.props.hour3[2]}</span>
                        Humidity: <span className="col-sm weather__value">{this.props.hour3[3]}</span>
                    </div>
                )}
                {this.props.hour4 && (
                    <div className="col-sm weather__key">
                        Hour: <span className="col-sm weather__value">{moment(this.props.hour4[0]).format('lll')}</span>
                        Temperature: <span className="col-sm weather__value">{this.props.hour4[1]}</span>
                        Description: <span className="col-sm weather__value">{this.props.hour4[2]}</span>
                        Humidity: <span className="col-sm weather__value">{this.props.hour4[3]}</span>
                    </div>
                )}
                
                {this.props.hour1 && <div className="showMore" onClick={this.toggleClick}>{this.showMore ? "Show less days" : "Show more days"}</div>}

                {this.showMore && (  
                    <div>
                        <div className="col-sm weather__key">
                            <p>TemperatureDay1: {this.props.temperatureDay1}</p>
                            <p>HumidityDay1: {this.props.humidityDay1}</p>
                            <p>ConditionsDay1: {this.props.descriptionDay1}</p>
                        </div>
                        <div className="col-sm weather__key">
                            <p>TemperatureDay2: {this.props.temperatureDay2}</p>
                            <p>HumidityDay2: {this.props.humidityDay2}</p>
                            <p>ConditionsDay2: {this.props.descriptionDay2}</p>
                        </div>

                        <div className="col-sm weather__key">
                            <p>TemperatureDay3: {this.props.temperatureDay3}</p>
                            <p>HumidityDay3: {this.props.humidityDay3}</p>
                            <p>ConditionsDay3: {this.props.descriptionDay3}</p>
                        </div>

                        <div className="col-sm weather__key">
                            <p>TemperatureDay4: {this.props.temperatureDay4}</p>
                            <p>HumidityDay4: {this.props.humidityDay4}</p>
                            <p>ConditionsDay4: {this.props.descriptionDay4}</p>
                        </div>

                        <div className="col-sm weather__key">
                            <p>TemperatureDay5: {this.props.temperatureDay5}</p>
                            <p>HumidityDay5: {this.props.humidityDay5}</p>
                            <p>ConditionsDay5: {this.props.descriptionDay5}</p>
                        </div>
                    </div>
                )}

            </div>
        );
        }

}

export default Weather;

//url("img/bg.jpg")