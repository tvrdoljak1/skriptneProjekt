import React from 'react';
import Titles from "./components/Titles";
import Form from "./components/Form";
import Weather from "./components/Weather";



const API_KEY = "11eccb7b8c45fd5a66fe79eee070f8db";

class App extends React.Component{

  state = {

    
    city: undefined,
    country: undefined,
    temperature: undefined,
    
    humidity: undefined,
    description: undefined,
    error: undefined,
    tommorrow: undefined,
    day2date: undefined,
    tommorrow3: undefined,
    day3date: undefined,
    tommorrow4: undefined,
    day4date: undefined,
    tommorrow5: undefined,
    day5date: undefined,
    

  }

    getWeather = async (e) => {
    e.preventDefault();
    const city = e.target.elements.city.value;
    const country = e.target.elements.country.value;
   
         const response = await fetch(`http://api.openweathermap.org/data/2.5/forecast?q=${city},${country}&appid=${API_KEY}&units=metric`);
         const data = await response.json();

  if(city){

    console.log(data);

    this.setState({

      city: data.city.name,
      country: data.city.country,
      temperature: data.list[0].main.temp,
      humidity: data.list[0].main.humidity,
      description: data.list[0].weather[0].description,
      tommorrow: data.list[8].main.temp,
      day2date: data.list[8].dt_txt,
      tommorrow3: data.list[16].main.temp,
      day3date: data.list[16].dt_txt,
      tommorrow4: data.list[24].main.temp,
      day4date: data.list[24].dt_txt,
      tommorrow5: data.list[30].main.temp,
      day5date: data.list[30].dt_txt
    
  
    });


  }else{


    this.setState({

      city: undefined,
      country: undefined,
      temperature: undefined,
      humidity: undefined,
      description: "U must enter values.",
      tommorrow: undefined,
      day2date: undefined,
      tommorrow3: undefined,
      day3date: undefined,
      tommorrow4: undefined,
      day4date: undefined,
      tommorrow5: undefined,
      day5date: undefined,
      
    
  
    });


  }

  
    

  }
  render(){
    return(

      <div>

          
        <div className="wrapper">

          <div className="main">

            <div className="container">

              <div className="row">

                <div className="col-xs-5 title-container">

                <Titles />

                </div>

                <div className="col-xs-7 form-container">

                        <Form getWeather={this.getWeather}/>
                        <Weather 
                        city = {this.state.city}
                        country = {this.state.country}
                        temperature={this.state.temperature}
                        humidity = {this.state.humidity}
                        description = {this.state.description}
                        error = {this.state.error}
                        tommorrow = {this.state.tommorrow}
                      //day2dateAr = {this.state.day2date.split[" "]}
                        day2date = {this.state.day2date}
                        tommorrow3 = {this.state.tommorrow3}
                        day3date = {this.state.day3date}
                        tommorrow4 = {this.state.tommorrow4}
                        day4date = {this.state.day4date}
                        tommorrow5 = {this.statetommorrow5}
                        day5date = {this.state.day5date}

                        />

                </div>

              </div>

            </div>

          </div>  
          
        </div>
        

      </div>

    );
  }

};

export default App;


        