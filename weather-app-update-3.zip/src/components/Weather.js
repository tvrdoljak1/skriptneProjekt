import React from "react";

const Weather = (props) => {
    return (

        <div className="weather__info">

                {
                   props.city && props.country && <p className="weather__key">Location:
                       <span className="weather__value"> {props.city},{props.country}</span>
                 </p>

                }
                {
                props.temperature && <p className="weather__key">Temperature: 
                    <span className="weather__value"> {props.temperature} </span><span>&#8451;</span>
                    </p>
                }
                {
                props.humidity && <p className="weather__key">Humidiry: 
                    <span className="weather__value"> {props.humidity}</span>
                    </p>
                }
                {
                props.description && <p className="weather__key">Description: 
                    <span className="weather__value"> {props.description}</span>
                    </p>
                }
                {
                props.error && <p className="weather__">{props.error}</p>
                }
                
                {
                props.tommorrow && props.day2date && <p className="weather__key">{props.day2date}:
                    <span className="weather__value">{props.tommorrow} </span> <span>&#8451;</span>
                    </p>
                }

                {
                props.tommorrow3 && props.day3date && <p className="weather__key">{props.day3date}:
                    <span className="weather__value">{props.tommorrow3} </span> <span>&#8451;</span>
                    </p>
                }

                {
                props.tommorrow4 && props.day4date && <p className="weather__key">{props.day4date}:
                    <span className="weather__value">{props.tommorrow4} </span> <span>&#8451;</span>
                    </p>
                }
                {
                props.tommorrow5 && props.day5date && <p className="weather__key">{props.day5date}:
                    <span className="weather__value">{props.tommorrow5} </span> <span>&#8451;</span>
                    </p>
                }

                

                

            </div>

    );
}

export default Weather;