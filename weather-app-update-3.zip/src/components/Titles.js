import React from 'react';

const Titles = () => {

    return(

        <div>
         
         <h1 className ="title-container__title">Weather App</h1>
    
        </div>

    );

};

export default Titles;