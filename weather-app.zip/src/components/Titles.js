import React from 'react';

class Titles extends React.Component{

    render(){

        return(

            <div>
                <h1>Weather Finder</h1>
                <p>Find out temperatuer, conditions and more...</p>  
            </div>

        );

    }

};

export default Titles;