import React from "react";

class Weather extends React.Component{

    render(){
        return(

            <div> Weather Components</div>

        );
    }

};

export default Weather;